package com.infy.productms.product.repositoty;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;


import com.infy.productms.product.entity.SubscribedProduct;



public interface SubscribedProductRepositoty extends JpaRepository<SubscribedProduct,Integer>  {
	List<SubscribedProduct> findByBuyerid(Integer buyerid);

}
